package com.controler;

import java.util.List;
import java.util.Optional;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.relational.core.conversion.DbAction.WithEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.enitiy.Whatsapp;
import com.service.WService;

@RestController
@RequestMapping("/whatsapp")
public class WControler {
	@Autowired
	private WService wService;
	
	@PostMapping("/save")
	public Whatsapp addData(@RequestBody Whatsapp whatsapp) {
		return wService.save(whatsapp);
	}
	
	@GetMapping("/get/{id}")
	public Whatsapp getById(@PathVariable (value="id") int id) {
		return wService.getById(id);
	}
	
	@GetMapping("/getAll")
	public List<Whatsapp> getAll(){
		return wService.getAll();
	}
	
	@PutMapping("/update/{id}")
	public String update(@PathVariable Integer id) {
		wService.update(id);
		return "updated";
		 
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteById(@PathVariable (value = "id") int id) {
		 wService.deleteById(id);
		
	}
	
	
	
	

}
