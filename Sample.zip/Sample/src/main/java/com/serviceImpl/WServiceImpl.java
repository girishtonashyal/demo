package com.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.enitiy.Whatsapp;
import com.repository.WRepository;
import com.service.WService;

@Service
public class WServiceImpl implements WService {
	@Autowired
	private WRepository wRepository;

	@Override
	public List<Whatsapp> getAll() {
		
		return wRepository.findAll();				
	}

	@Override
	public Whatsapp save(Whatsapp whatsapp) {
		
		return wRepository.save(whatsapp);
	}

	@Override
	public Whatsapp getById(int id) {
		
		return wRepository.getById(id);
	}

	@Override
	public Whatsapp update(Integer id) {
		return wRepository.save(id);
		}
	
	@Override
	public void deleteById(int id) {
		 wRepository.deleteById(id);
		
	}
	

	
	
}
