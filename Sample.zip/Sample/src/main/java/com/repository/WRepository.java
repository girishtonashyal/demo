package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.enitiy.Whatsapp;

public interface WRepository extends JpaRepository<Whatsapp, Integer> {

	Whatsapp save(Integer id);
	
	 

}
