package com.service;

import java.util.List;
import java.util.Optional;

import com.enitiy.Whatsapp;

public interface WService {

	public List<Whatsapp> getAll();

	Whatsapp save(Whatsapp whatsapp);

	Whatsapp getById(int id);

	public Whatsapp update(Integer id);
	
	public void deleteById(int id);
	
	

	

}
